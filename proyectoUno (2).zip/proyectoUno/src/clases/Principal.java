package clases;
import model.Conexion;


public class Principal {

    
    public static void main(String[] args) {
       Conexion objConectar = new Conexion();
       objConectar.establecerConexion();
    }
    
}
