package controller;

import java.sql.Connection; //contiene metodos para abrir y cerrar conexiones
import java.sql.PreparedStatement; //contiene metodos para crear consultas SQL
import java.sql.ResultSet; //contiene metodos para leer datos devueltos por BD
import java.sql.SQLException; //maneja errores
import model.Conexion;

public class Login {

    public ResultSet validarUsuario(String usuario, String clave) throws SQLException {
        Conexion objetoConexion = new Conexion();
        Connection conexion = objetoConexion.establecerConexion();
        if (conexion == null) {
            return null;
        }
        String sql = "SELECT * FROM usuarios WHERE nombreUsuario=? AND passwordUsuario=?";

        PreparedStatement consultaLogin = conexion.prepareStatement(sql);
        consultaLogin.setString(1, usuario);
        consultaLogin.setString(2, clave);
        return consultaLogin.executeQuery(sql);

    }
}
