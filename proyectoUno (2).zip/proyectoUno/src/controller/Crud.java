
package controller;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import model.Conexion;

public class Crud {
    
    public void grabar(String rut, String dv, String nombres,
            String apellidos, int edad, String ciudad, String sexo){
    
        String sql = "INSERT INTO Alumnos (rut, dv, nombres, apellidos"
                + "edad, ciudad, sexo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Conexion conexionDB = new Conexion();
            Connection conexionActiva = conexionDB.establecerConexion();
            
            PreparedStatement consultaSQL = conexionActiva.prepareStatement(sql);
            consultaSQL.setString(1, rut);
            consultaSQL.setString(2, dv);
            consultaSQL.setString(3, nombres);
            consultaSQL.setString(4, apellidos);
            consultaSQL.setInt(5, edad);
            consultaSQL.setString(6, ciudad);
            consultaSQL.setString(7, sexo);
        
            consultaSQL.executeUpdate();
            JOptionPane.showMessageDialog(null, "Alumno grabado correctamente");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al grabar");
        }
        
    }  
}
