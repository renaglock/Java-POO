package view;

import model.Lectura;
import model.Mazo;
import model.TarotDAO;
import model.TipoLectura;
import javax.swing.JOptionPane;

public class frmMain extends javax.swing.JFrame {
    


    // 1. INSTANCIAS GLOBALES (Para conectar con la BD)
    TarotDAO dao = new TarotDAO();

    public frmMain() {
        initComponents();
        this.setLocationRelativeTo(null); // Centrar
        this.setTitle("Gesti�n de Lecturas de Tarot");

        // 2. CONFIGURACI�N INICIAL
        cargarCombos();     // Llena los combos desde MySQL
        cargarTabla("");    // Llena la tabla
        txtId.setEnabled(false); // Bloqueamos ID para que no se edite manual

        // Forzar que se seleccione la fila entera y solo una a la vez
        tblLecturas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblLecturas.setRowSelectionAllowed(true);
        tblLecturas.setColumnSelectionAllowed(false);       
    }

    // --- M�TODOS AUXILIARES  ---
    void cargarCombos() {
        dao.cargarMazos(cmbMazo);
        dao.cargarTipos(cmbTipo);
    }

    void cargarTabla(String buscar) {
        tblLecturas.setModel(dao.listar(buscar));
    }

    void limpiar() {
        txtId.setText("");
        txtCliente.setText("");
        txtFecha.setText("");
        txtCosto.setText("");
        // Reiniciar combos al primer elemento
        if (cmbMazo.getItemCount() > 0) {
            cmbMazo.setSelectedIndex(0);
        }
        if (cmbTipo.getItemCount() > 0) {
            cmbTipo.setSelectedIndex(0);
        }
        txtBuscar.setText("");
        cargarTabla(""); // Refrescar la tabla
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtCliente = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();
        txtCosto = new javax.swing.JTextField();
        cmbMazo = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        txtBuscar = new javax.swing.JTextField();
        lblBuscar = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLecturas = new javax.swing.JTable();
        txtId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        lblCosto = new javax.swing.JLabel();
        lblMazo = new javax.swing.JLabel();
        lblLectura = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jLabel1.setBackground(new java.awt.Color(102, 102, 102));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/bola-de-cristal.png"))); // NOI18N

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/bola-de-cristal (1).png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        getContentPane().add(txtCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 50, 180, 30));

        txtFecha.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        getContentPane().add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 180, 30));

        txtCosto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        getContentPane().add(txtCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 180, 30));

        cmbMazo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbMazo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(cmbMazo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 180, 30));

        cmbTipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(cmbTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 180, 30));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 110, 50));

        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 407, 110, 50));

        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 110, 50));

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 407, 110, 50));

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel2.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 180, 30));

        lblBuscar.setBackground(new java.awt.Color(255, 255, 255));
        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(255, 255, 255));
        lblBuscar.setText("Buscar por nombre:");
        jPanel2.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, 20));

        tblLecturas.setAutoCreateRowSorter(true);
        tblLecturas.setBackground(new java.awt.Color(153, 153, 153));
        tblLecturas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tblLecturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblLecturas.setCellSelectionEnabled(true);
        tblLecturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLecturasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblLecturas);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 340, 390));

        txtId.setEditable(false);
        txtId.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        txtId.setEnabled(false);
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel2.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 20, -1));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/bola-de-cristal (1).png"))); // NOI18N
        jLabel4.setPreferredSize(new java.awt.Dimension(55, 55));
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 120, 110));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 0, 340, 500));

        lblNombre.setBackground(new java.awt.Color(255, 255, 255));
        lblNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre.setText("Nombre del Cliente");
        getContentPane().add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, -1));

        lblFecha.setBackground(new java.awt.Color(255, 255, 255));
        lblFecha.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(255, 255, 255));
        lblFecha.setText("Fecha");
        getContentPane().add(lblFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, -1));

        lblCosto.setBackground(new java.awt.Color(255, 255, 255));
        lblCosto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCosto.setForeground(new java.awt.Color(255, 255, 255));
        lblCosto.setText("Costo");
        getContentPane().add(lblCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        lblMazo.setBackground(new java.awt.Color(255, 255, 255));
        lblMazo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblMazo.setForeground(new java.awt.Color(255, 255, 255));
        lblMazo.setText("Mazo");
        getContentPane().add(lblMazo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        lblLectura.setBackground(new java.awt.Color(255, 255, 255));
        lblLectura.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblLectura.setForeground(new java.awt.Color(255, 255, 255));
        lblLectura.setText("Lectura");
        getContentPane().add(lblLectura, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(272, 121, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resource/lupa.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -60, 500, 720));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // Validaciones
        if (txtCliente.getText().isEmpty() || txtFecha.getText().isEmpty() || txtCosto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos.");
            return;
        }

        Lectura l = new Lectura();
        l.setCliente(txtCliente.getText());
        l.setFecha(txtFecha.getText());

        try {
            l.setCosto(Integer.parseInt(txtCosto.getText()));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El costo debe ser un n�mero v�lido.");
            return;
        }

        // Obtener los objetos seleccionados en los ComboBox
        Mazo mazoSeleccionado = (Mazo) cmbMazo.getSelectedItem();
        l.setIdMazo(mazoSeleccionado.getId());

        TipoLectura tipoSeleccionado = (TipoLectura) cmbTipo.getSelectedItem();
        l.setIdTipo(tipoSeleccionado.getId());

        // L�gica: Si txtId est� vac�o es NUEVO, si tiene n�mero es EDITAR
        if (txtId.getText().isEmpty()) {
            if (dao.registrar(l)) {
                JOptionPane.showMessageDialog(this, "Lectura registrada correctamente.");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar.");
            }
        } else {
            l.setId(Integer.parseInt(txtId.getText()));
            if (dao.modificar(l)) {
                JOptionPane.showMessageDialog(this, "Lectura modificada correctamente.");
                limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "Error al modificar.");
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if (!txtId.getText().isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(this, "�Seguro que desea eliminar esta lectura?", "Confirmar", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                int id = Integer.parseInt(txtId.getText());
                if (dao.eliminar(id)) {
                    JOptionPane.showMessageDialog(this, "Registro eliminado.");
                    limpiar();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione una fila de la tabla para eliminar.");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        cargarTabla(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tblLecturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLecturasMouseClicked
        int fila = tblLecturas.getSelectedRow();
        if (fila >= 0) {
            // Pasar datos de la tabla a los cuadros de texto
            txtId.setText(tblLecturas.getValueAt(fila, 0).toString());
            txtCliente.setText(tblLecturas.getValueAt(fila, 1).toString());
            txtFecha.setText(tblLecturas.getValueAt(fila, 2).toString());
            txtCosto.setText(tblLecturas.getValueAt(fila, 3).toString());

            // Seleccionar inteligentemente los ComboBox
            String nombreMazo = tblLecturas.getValueAt(fila, 4).toString();
            String nombreTipo = tblLecturas.getValueAt(fila, 5).toString();

            // Recorremos el combo para encontrar el objeto que coincida con el nombre
            for (int i = 0; i < cmbMazo.getItemCount(); i++) {
                if (cmbMazo.getItemAt(i).toString().equals(nombreMazo)) {
                    cmbMazo.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cmbTipo.getItemCount(); i++) {
                if (cmbTipo.getItemAt(i).toString().equals(nombreTipo)) {
                    cmbTipo.setSelectedIndex(i);
                    break;
                }
            }
        }
    }//GEN-LAST:event_tblLecturasMouseClicked

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

        // 1. VALIDACI�N PREVIA: �Hay un ID seleccionado?
        if (txtId.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione una lectura de la tabla para modificar.");
            return;
        }

        // 2. Validar campos vac�os
        if (txtCliente.getText().isEmpty() || txtFecha.getText().isEmpty() || txtCosto.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "No puede dejar campos vac�os.");
            return;
        }

        // 3. Crear el objeto con los datos nuevos
        model.Lectura l = new model.Lectura();
        // IMPORTANTE: Aqu� asignamos el ID que recuperamos de la caja de texto
        l.setId(Integer.parseInt(txtId.getText()));

        l.setCliente(txtCliente.getText());
        l.setFecha(txtFecha.getText());

        try {
            l.setCosto(Integer.parseInt(txtCosto.getText()));
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "El costo debe ser num�rico.");
            return;
        }

        // Obtener IDs de los ComboBox
        model.Mazo mazo = (model.Mazo) cmbMazo.getSelectedItem();
        l.setIdMazo(mazo.getId());

        model.TipoLectura tipo = (model.TipoLectura) cmbTipo.getSelectedItem();
        l.setIdTipo(tipo.getId());

        // 4. LLAMAR AL DAO (Update)
        if (dao.modificar(l)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Lectura modificada correctamente.");
            limpiar(); // Limpiamos para soltar el registro
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Error al modificar en base de datos.");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // Mostramos el mensaje de confirmaci�n
        int confirm = javax.swing.JOptionPane.showConfirmDialog(
            this,
            "�Est� seguro que desea salir del sistema?",
            "Confirmar Salida",
            javax.swing.JOptionPane.YES_NO_OPTION
        );

        // Si dice que S�, matamos el programa completamente
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            System.exit(0);
        }
        // Si dice que NO, no hacemos nada (y como pusimos DO_NOTHING, la ventana sigue abierta)
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<String> cmbMazo;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCosto;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblLectura;
    private javax.swing.JLabel lblMazo;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTable tblLecturas;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
