CREATE DATABASE IF NOT EXISTS tarot_db;
USE tarot_db;

-- 1. Tabla para el Login 
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- 2. Tabla para el Primer ComboBox 
CREATE TABLE mazos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

-- 3. Tabla para el Segundo ComboBox 
CREATE TABLE tipos_lectura (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(50) NOT NULL
);

-- 4. Tabla Principal para el CRUD 
CREATE TABLE lecturas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_nombre VARCHAR(100) NOT NULL,
    fecha DATE,
    costo INT,
    id_mazo INT,
    id_tipo INT,
    FOREIGN KEY (id_mazo) REFERENCES mazos(id),
    FOREIGN KEY (id_tipo) REFERENCES tipos_lectura(id)
);

-- Insertamos datos de prueba (Vitales para que los ComboBox no salgan vac�os)

INSERT INTO usuarios (username, password) VALUES ('admin', '1234'), ('juanito', '1234');

INSERT INTO mazos (nombre) VALUES ('Rider Waite'), ('Marsella'), ('Egipcio'), ('Osho Zen');

INSERT INTO tipos_lectura (descripcion) VALUES ('Lectura de Amor'), ('Lectura Laboral'), ('Cruz Celta'), ('Tirada de 3 Cartas');

INSERT INTO lecturas (cliente_nombre, fecha, costo, id_mazo, id_tipo) VALUES ('Renato', '2025-12-07', 15000, 1, 2);