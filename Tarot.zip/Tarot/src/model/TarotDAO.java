package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

public class TarotDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    // --- 1. M�TODO PARA EL LOGIN (Requisito 6) ---
    public boolean login(String user, String pass) {
        String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            if (rs.next()) {
                return true; // Usuario encontrado
            }
        } catch (SQLException e) {
            System.err.println("Error en Login: " + e.toString());
        } finally {
           Conexion.desconectar(con);
        }
        return false;
    }

    // --- 2. LLENAR COMBOBOX DIN�MICOS (Requisito 4) ---
    // Uso objetos completos en el combo
    public void cargarMazos(JComboBox cmb) {
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        String sql = "SELECT * FROM mazos";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            // Agregamos un item por defecto
            cmb.removeAllItems(); // Limpiar primero
            
            while (rs.next()) {
                // Creamos el objeto y lo metemos al combo
                model.addElement(new Mazo(rs.getInt("id"), rs.getString("nombre")));
            }
            cmb.setModel(model);
        } catch (SQLException e) {
            System.err.println("Error cargando mazos: " + e.toString());
        }
    }

    public void cargarTipos(JComboBox cmb) {
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        String sql = "SELECT * FROM tipos_lectura";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            cmb.removeAllItems();
            
            while (rs.next()) {
                model.addElement(new TipoLectura(rs.getInt("id"), rs.getString("descripcion")));
            }
            cmb.setModel(model);
        } catch (SQLException e) {
            System.err.println("Error cargando tipos: " + e.toString());
        }
    }

    // --- 3. REGISTRAR LECTURA (CRUD - Create) ---
    public boolean registrar(Lectura l) {
        String sql = "INSERT INTO lecturas (cliente_nombre, fecha, costo, id_mazo, id_tipo) VALUES (?, ?, ?, ?, ?)";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            ps.setString(1, l.getCliente());
            ps.setString(2, l.getFecha());
            ps.setInt(3, l.getCosto());
            ps.setInt(4, l.getIdMazo());
            ps.setInt(5, l.getIdTipo());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al registrar: " + e.toString());
            return false;
        }
    }

    // --- 4. ELIMINAR LECTURA (CRUD - Delete) ---
    public boolean eliminar(int id) {
        String sql = "DELETE FROM lecturas WHERE id = ?";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al eliminar: " + e.toString());
            return false;
        }
    }
    
    // --- 5. MODIFICAR LECTURA (CRUD - Update) ---
    public boolean modificar(Lectura l) {
        String sql = "UPDATE lecturas SET cliente_nombre=?, fecha=?, costo=?, id_mazo=?, id_tipo=? WHERE id=?";
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            ps.setString(1, l.getCliente());
            ps.setString(2, l.getFecha());
            ps.setInt(3, l.getCosto());
            ps.setInt(4, l.getIdMazo());
            ps.setInt(5, l.getIdTipo());
            ps.setInt(6, l.getId()); // El ID va al final en el WHERE
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println("Error al modificar: " + e.toString());
            return false;
        }
    }
    
    // --- 6. LISTAR Y BUSCAR ---
    // Retornamos directamente el modelo para pegarlo en la JTable
    public javax.swing.table.DefaultTableModel listar(String buscar) {
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
        // Definimos las columnas de la tabla
        modelo.addColumn("ID");
        modelo.addColumn("Cliente");
        modelo.addColumn("Fecha");
        modelo.addColumn("Costo");
        modelo.addColumn("Mazo");
        modelo.addColumn("Tipo");

        // El SQL incluye JOINS para traer los nombres reales de los mazos y tipos
        String sql = "SELECT l.id, l.cliente_nombre, l.fecha, l.costo, m.nombre AS nombre_mazo, t.descripcion AS nombre_tipo "
                   + "FROM lecturas l "
                   + "INNER JOIN mazos m ON l.id_mazo = m.id "
                   + "INNER JOIN tipos_lectura t ON l.id_tipo = t.id "
                   + "WHERE l.cliente_nombre LIKE '%" + buscar + "%' ORDER BY l.id DESC";
        
        try {
            con = Conexion.conectar();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            // Llenamos las filas
            while (rs.next()) {
                Object[] fila = new Object[6];
                fila[0] = rs.getInt("id");
                fila[1] = rs.getString("cliente_nombre");
                fila[2] = rs.getString("fecha");
                fila[3] = rs.getInt("costo");
                fila[4] = rs.getString("nombre_mazo");
                fila[5] = rs.getString("nombre_tipo");
                modelo.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar: " + e.toString());
        }
        return modelo;
    }
}