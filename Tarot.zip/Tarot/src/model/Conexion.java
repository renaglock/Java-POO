package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {

    // Configuraci�n de la conexi�n
    private static final String URL = "jdbc:mysql://localhost:3306/tarot_db";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection conectar() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexi�n exitosa");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de Conexi�n: " + e.getMessage());
        }
        return con;
    }

    public static void desconectar(Connection con) {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Conexi�n cerrada");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexi�n: " + e.getMessage());
        }
    }
}
