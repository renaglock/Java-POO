package model;

public class Lectura {
    private int id;
    private String cliente;
    private String fecha; // Guardaremos como texto "YYYY-MM-DD" para facilitar las cosas
    private int costo;
    private int idMazo;
    private int idTipo;

    // Constructor vac�o
    public Lectura() {
    }

    // Constructor con datos
    public Lectura(String cliente, String fecha, int costo, int idMazo, int idTipo) {
        this.cliente = cliente;
        this.fecha = fecha;
        this.costo = costo;
        this.idMazo = idMazo;
        this.idTipo = idTipo;
    }

    // Getters y Setters (Click derecho > Insert Code > Getter and Setter > Select All)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getCliente() { return cliente; }
    public void setCliente(String cliente) { this.cliente = cliente; }
    
    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    
    public int getCosto() { return costo; }
    public void setCosto(int costo) { this.costo = costo; }
    
    public int getIdMazo() { return idMazo; }
    public void setIdMazo(int idMazo) { this.idMazo = idMazo; }
    
    public int getIdTipo() { return idTipo; }
    public void setIdTipo(int idTipo) { this.idTipo = idTipo; }
}
