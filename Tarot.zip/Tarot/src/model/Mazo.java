package model;

public class Mazo {
    private int id;
    private String nombre;

    public Mazo() {}

    public Mazo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    // Este toString es CRUCIAL para que el ComboBox muestre el nombre y no la direcci�n de memoria
    @Override
    public String toString() {
        return nombre;
    }
}