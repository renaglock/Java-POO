USUARIOS:
'admin' '1234'
'juanito' '1234'

-La busqueda del programa solo funciona por nombre.
-Para guardar una lectura se deben llenar los campos manualmente (no tomar un registro y editarlo. Eso solo lo modifica).