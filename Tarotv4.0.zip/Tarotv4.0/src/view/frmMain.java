package view;

import model.Lectura;
import model.Mazo;
import model.TarotDAO;
import model.TipoLectura;
import javax.swing.JOptionPane;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;

public class frmMain extends javax.swing.JFrame {

    // INSTANCIAS GLOBALES
    TarotDAO dao = new TarotDAO();

    public frmMain() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Gesti�n de Lecturas de Tarot");
        this.setResizable(false);

        //cambiar el icono de la taza de java
        try {
            javax.swing.ImageIcon icono = new javax.swing.ImageIcon(getClass().getResource("/resource/mandala.png"));
            this.setIconImage(icono.getImage());
        } catch (Exception e) {
            System.err.println("Error cargando icono: " + e);
        }

        // CONFIGURACI�N INICIAL
        cargarCombos();     // Llena los combos desde MySQL
        cargarTabla("");    // Llena la tabla
        txtId.setEnabled(false); // Bloqueamos ID para que no se edite manual

        // Forzar que se seleccione la fila entera y solo una a la vez en la tabla
        tblLecturas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblLecturas.setRowSelectionAllowed(true);
        tblLecturas.setColumnSelectionAllowed(false);

        pintarImagen(lblLupa, "/resource/lupa.png");
    }

    // --- M�TODOS AUXILIARES  ---
    void cargarCombos() {
        dao.cargarMazos(cmbMazo);
        dao.cargarTipos(cmbTipo);
    }

    void cargarTabla(String buscar) {
        tblLecturas.setModel(dao.listar(buscar));
    }

    void limpiar() {
        txtId.setText("");
        txtCliente.setText("");
        dtFecha.setDate(null);
        txtCosto.setText("");
        cmbMazo.setSelectedIndex(0);
        cmbTipo.setSelectedIndex(0);
        txtBuscar.setText("");
        cargarTabla(""); // Refrescar la tabla
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        txtBuscar = new javax.swing.JTextField();
        lblBuscar = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLecturas = new javax.swing.JTable();
        txtId = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        txtCliente = new javax.swing.JTextField();
        txtCosto = new javax.swing.JTextField();
        cmbMazo = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        dtFecha = new com.toedter.calendar.JDateChooser();
        lblCosto = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblLectura = new javax.swing.JLabel();
        lblMazo = new javax.swing.JLabel();
        lblLupa = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });
        jPanel2.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 210, 30));

        lblBuscar.setBackground(new java.awt.Color(255, 255, 255));
        lblBuscar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblBuscar.setForeground(new java.awt.Color(255, 255, 255));
        lblBuscar.setText("Buscar por nombre:");
        jPanel2.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 160, 20));

        tblLecturas.setAutoCreateRowSorter(true);
        tblLecturas.setBackground(new java.awt.Color(153, 153, 153));
        tblLecturas.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tblLecturas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblLecturas.setCellSelectionEnabled(true);
        tblLecturas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLecturasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblLecturas);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 360, 370));

        txtId.setEditable(false);
        txtId.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        txtId.setEnabled(false);
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel2.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 20, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 370, 500));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCliente.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jPanel1.add(txtCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 180, 30));

        txtCosto.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txtCosto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCostoActionPerformed(evt);
            }
        });
        txtCosto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCostoKeyTyped(evt);
            }
        });
        jPanel1.add(txtCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 180, 30));

        cmbMazo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbMazo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        jPanel1.add(cmbMazo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 180, 30));

        cmbTipo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        jPanel1.add(cmbTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 180, 30));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel1.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 350, 130, 50));

        btnLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnLimpiar.setText("Limpiar");
        btnLimpiar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, 130, 50));

        btnModificar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 350, 130, 50));

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, 130, 50));

        dtFecha.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(dtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 180, 30));

        lblCosto.setBackground(new java.awt.Color(255, 255, 255));
        lblCosto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCosto.setForeground(new java.awt.Color(255, 255, 255));
        lblCosto.setText("Costo");
        jPanel1.add(lblCosto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, -1, -1));

        lblFecha.setBackground(new java.awt.Color(255, 255, 255));
        lblFecha.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFecha.setForeground(new java.awt.Color(255, 255, 255));
        lblFecha.setText("Fecha");
        jPanel1.add(lblFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, -1, -1));

        lblNombre.setBackground(new java.awt.Color(255, 255, 255));
        lblNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblNombre.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre.setText("Nombre del Cliente");
        jPanel1.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));

        lblLectura.setBackground(new java.awt.Color(255, 255, 255));
        lblLectura.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblLectura.setForeground(new java.awt.Color(255, 255, 255));
        lblLectura.setText("Lectura");
        jPanel1.add(lblLectura, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));

        lblMazo.setBackground(new java.awt.Color(255, 255, 255));
        lblMazo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblMazo.setForeground(new java.awt.Color(255, 255, 255));
        lblMazo.setText("Mazo");
        jPanel1.add(lblMazo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, -1, -1));
        jPanel1.add(lblLupa, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 100, 450, 450));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // 1. VALIDACI�N DE SEGURIDAD: �Hay un ID en pantalla?
        // Si hay ID, el usuario deber�a usar "Modificar", no "Guardar".
        if (!txtId.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Est�s viendo un registro existente (ID " + txtId.getText() + ").\n"
                    + "Utiliza el bot�n 'Modificar' para guardar cambios\n"
                    + "o presiona 'Limpiar' para crear uno nuevo.",
                    "Acci�n Incorrecta",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. VALIDAR CAMPOS VAC�OS (Nombre, Fecha del Calendario, Costo)
        if (txtCliente.getText().isEmpty() || dtFecha.getDate() == null || txtCosto.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Por favor, complete todos los campos obligatorios.",
                    "Faltan Datos",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 3. VALIDAR COMBOS (AQU� SE ARREGLA TU ERROR DE SQL)
        model.Mazo mazo = (model.Mazo) cmbMazo.getSelectedItem();
        model.TipoLectura tipo = (model.TipoLectura) cmbTipo.getSelectedItem();

        // Si el ID es 0, significa que seleccionaste "--------". 
        // NO dejamos pasar esto porque MySQL explotar�a.
        if (mazo.getId() == 0 || tipo.getId() == 0) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Debe seleccionar un Mazo y un Tipo de Lectura reales.",
                    "Selecci�n Inv�lida",
                    javax.swing.JOptionPane.WARNING_MESSAGE);
            return; // <--- ESTE RETURN ES EL QUE SALVA TU PROGRAMA
        }

        // 4. PREPARAR EL OBJETO
        model.Lectura l = new model.Lectura();
        l.setCliente(txtCliente.getText());

        // Conversi�n de Fecha (Del Calendario visual a Texto para MySQL)
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
        String fechaFormateada = sdf.format(dtFecha.getDate());
        l.setFecha(fechaFormateada);

        // Conversi�n de Costo
        try {
            l.setCosto(Integer.parseInt(txtCosto.getText()));
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "El costo no es v�lido.",
                    "Error Cr�tico",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Asignamos los IDs (Ya sabemos que NO son 0 gracias al paso 3)
        l.setIdMazo(mazo.getId());
        l.setIdTipo(tipo.getId());

        // 5. ENVIAR AL DAO
        if (dao.registrar(l)) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Lectura guardada exitosamente.",
                    "�xito!",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE);
            limpiar(); // Limpiamos para dejar listo el siguiente
        } else {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Ocurri� un error al guardar en la base de datos.\nRevise la consola.",
                    "Error Cr�tico",
                    javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if (!txtId.getText().isEmpty()) {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "�Seguro que desea eliminar esta lectura?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                int id = Integer.parseInt(txtId.getText());
                if (dao.eliminar(id)) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Registro eliminado.",
                            "�xito!",
                            javax.swing.JOptionPane.INFORMATION_MESSAGE
                    );
                    limpiar();
                }
            }
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Seleccione una fila para eliminar.",
                    "Seleccionar Fila",
                    javax.swing.JOptionPane.WARNING_MESSAGE
            );
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
        cargarTabla(txtBuscar.getText());
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void tblLecturasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLecturasMouseClicked
        int fila = tblLecturas.getSelectedRow();

        if (fila >= 0) {
            // 1. Cargar ID y Cliente (Esto es texto seguro)
            txtId.setText(tblLecturas.getValueAt(fila, 0).toString());
            txtCliente.setText(tblLecturas.getValueAt(fila, 1).toString());

            // 2. Cargar FECHA (String -> Date)
            try {
                String fechaTexto = tblLecturas.getValueAt(fila, 2).toString();
                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
                java.util.Date fechaDate = sdf.parse(fechaTexto);
                dtFecha.setDate(fechaDate);
            } catch (Exception e) {
                System.out.println("Error fecha: " + e);
            }

            // 3. Cargar Costo
            txtCosto.setText(tblLecturas.getValueAt(fila, 3).toString());

            // 4. SELECCIONAR MAZO (Aqu� estaba el error)
            String nombreMazoEnTabla = tblLecturas.getValueAt(fila, 4).toString(); // Lo que dice la tabla

            for (int i = 0; i < cmbMazo.getItemCount(); i++) {
                // CORRECCI�N: No usamos (String), usamos .toString()
                // Esto obtiene el texto visual del objeto Mazo
                if (cmbMazo.getItemAt(i).toString().equals(nombreMazoEnTabla)) {
                    cmbMazo.setSelectedIndex(i);
                    break;
                }
            }

            // 5. SELECCIONAR TIPO (Misma correcci�n)
            String nombreTipoEnTabla = tblLecturas.getValueAt(fila, 5).toString();

            for (int i = 0; i < cmbTipo.getItemCount(); i++) {
                // CORRECCI�N: .toString()
                if (cmbTipo.getItemAt(i).toString().equals(nombreTipoEnTabla)) {
                    cmbTipo.setSelectedIndex(i);
                    break;
                }
            }
        }
    }//GEN-LAST:event_tblLecturasMouseClicked

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

        if (txtId.getText().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Seleccione un registro.",
                    "Seleccionar Registro",
                    javax.swing.JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Validaci�n de fecha vac�a
        if (dtFecha.getDate() == null) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "La fecha no puede estar vac�a.",
                    "Completar Fecha",
                    javax.swing.JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        model.Lectura l = new model.Lectura();
        l.setId(Integer.parseInt(txtId.getText())); // ID Obligatorio
        l.setCliente(txtCliente.getText());

        // --- CONVERSI�N DE FECHA (CALENDARIO -> STRING) ---
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaTexto = sdf.format(dtFecha.getDate());
        l.setFecha(fechaTexto);

        try {
            l.setCosto(Integer.parseInt(txtCosto.getText()));
        } catch (NumberFormatException e) {
            return;
        }

        model.Mazo mazo = (model.Mazo) cmbMazo.getSelectedItem();
        l.setIdMazo(mazo.getId());
        model.TipoLectura tipo = (model.TipoLectura) cmbTipo.getSelectedItem();
        l.setIdTipo(tipo.getId());

        if (dao.modificar(l)) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Modificado correctamente.",
                    "Exito!",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE
            );
            limpiar();
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // Mostramos el mensaje de confirmaci�n
        int confirm = javax.swing.JOptionPane.showConfirmDialog(
                this,
                "�Est� seguro que desea salir del sistema?",
                "Confirmar Salida",
                javax.swing.JOptionPane.YES_NO_OPTION
        );

        // Si dice que S�, matamos el programa completamente
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_formWindowClosing

    private void txtCostoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCostoKeyTyped
        char c = evt.getKeyChar();

        // VALIDACI�N DE TIPO: Solo n�meros, Backspace y Enter
        if (!Character.isDigit(c)
                && c != java.awt.event.KeyEvent.VK_BACK_SPACE
                && c != java.awt.event.KeyEvent.VK_ENTER) {

            evt.consume();
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "Solo puedes ingresar numeros en este campo.",
                    "Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE
            );
            return; // Detenemos aqu� si no es n�mero
        }

        // VALIDACI�N DE LONGITUD: M�ximo 9 d�gitos
        // Si la caja ya tiene 9 caracteres Y lo que presionaste NO es borrar/enter...
        if (txtCosto.getText().length() >= 9
                && c != java.awt.event.KeyEvent.VK_BACK_SPACE
                && c != java.awt.event.KeyEvent.VK_ENTER) {

            evt.consume(); // Bloqueamos la tecla
            java.awt.Toolkit.getDefaultToolkit().beep(); // Hace un sonido de "bip" de advertencia
        }
    }//GEN-LAST:event_txtCostoKeyTyped

    private void txtCostoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCostoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCostoActionPerformed
    // M�todo para ajustar la imagen al tama�o del JLabel
    private void pintarImagen(javax.swing.JLabel lbl, String ruta) {
        //Cargamos la imagen desde los recursos
        javax.swing.ImageIcon image = new javax.swing.ImageIcon(getClass().getResource(ruta));

        //Obtenemos las dimensiones actuales del JLabel (Ancho y Alto)
        int ancho = lbl.getWidth() > 0 ? lbl.getWidth() : 200;
        int alto = lbl.getHeight() > 0 ? lbl.getHeight() : 200;

        //Escalamos la imagen (SCALE_SMOOTH hace que no se pixelee tanto)
        java.awt.Image icon = image.getImage().getScaledInstance(ancho, alto, java.awt.Image.SCALE_SMOOTH);

        //Se la ponemos al label
        lbl.setIcon(new javax.swing.ImageIcon(icon));
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmMain().setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<String> cmbMazo;
    private javax.swing.JComboBox<String> cmbTipo;
    private com.toedter.calendar.JDateChooser dtFecha;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCosto;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblLectura;
    private javax.swing.JLabel lblLupa;
    private javax.swing.JLabel lblMazo;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTable tblLecturas;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
